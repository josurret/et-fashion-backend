'use strict';

module.exports = function(Categories) {

};
