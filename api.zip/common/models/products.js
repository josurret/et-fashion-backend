'use strict';

module.exports = function(Products) {

};
